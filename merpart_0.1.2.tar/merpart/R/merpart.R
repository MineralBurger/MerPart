merpart <-function(resp,preds, level, data,cut=3, type=NULL, ties=NULL,
                   comresp="Combined", maxcut=20, train=NULL, Cluster=NULL,
                   cp=NULL, seed=NULL, weighted=NULL)
{

  ##note levels currently order assigned to alphabetical order
  levela=level       #levels change to levela
  dat=data           #data put into function assigned dat
  dime=dim(dat)         #dimension of data frame
  ns=length(resp)    #defining size of left handside
  np=length(preds)   #defining size of right handside
  tot=ns+np          #total size of response and preds
  as<- data.frame(matrix(NA, ncol=tot, nrow=dime[1])) #create new dataframe from predictor and response variable
  names<-c(resp,preds)    #assign names of represonse and predictor variables to vector for use in a data frame
  colnames(as)<-names     #assign these name to new data frame
  cv=cut
  #Error check response and predictor variables listed

  for (i in 1:ns){
    if(as.factor(resp[i]) %in% names(dat)==TRUE) {
    }
    else {

      stop("Response variable: ", resp[i], ", not in data frame provided")
    }
  }


  for (i in 1:np){
    if(as.factor(preds[i]) %in% names(dat)==TRUE) {
    }
    else {

      stop("Predicator variable: ", preds[i], ", not in data frame provided")
    }
  }

  ##Make sure number of levels equal number of levels in response variable for each response to align with levels
  for(i in 1:ns){
    if(length(levels(dat[[resp[i]]]))==length(levela)) {
    }
    else if(length(levels(dat[[resp[i]]]))>length(levela)) {

      stop("Number of levels in: ", resp[i], ", are greater than the ", length(levela), " levels defined in level in merpart" )
    }
    else if(length(levels(dat[[resp[i]]]))<length(levela)){

      stop("Number of levels in: ", resp[i], ", are less than the ", length(levela), " levels defined in level in merpart" )

    }else {

    }
  }
  #Place data into dataframe into correct variable position.
  for (k in 1:ns)     # 1 to the length of the response variables
  {as[[resp[k]]]=dat[[resp[k]]]}    #assign the response variable entered into function and extract these value from data frame into new data frame
  for (k in 1:np)      # for 1 to the length of predictors
  {as[[preds[k]]]=dat[[preds[k]]]}  #assign the predictor variable entered into the function and extract those valye from data frame into new data frame

  #return(as)

  ##Setting up equations
  form=list()   #list of formula for simulation
  for (i in 1:ns)
  {preds1=unlist(preds)
  form[[i]] <- stats::as.formula(paste(as.name(resp[i]), paste(preds1, sep="", collapse ="+"), sep="~"))
  }

  ##setting up dataframe to save all cuts
  ##setting up dataframe names for combined cut
  vs=vector()
  vp=vector()
  for (i in cv:maxcut)
  {
    vs[i-(cv-1)]=paste("cut_",i,sep="")
  }
  ##setting up dataframe names for cuts cluster
  for (i in cv:maxcut)
  {
    vp[i-(cv-1)]=paste("clustercut_",i,sep="")
  }
  cct<- data.frame(matrix(NA, ncol=(maxcut-(cv-1))*2, nrow=dime[1])) #create new dataframe for cut
  names<-c(vs,vp)    #names for the cuts
  colnames(cct)<-names     #assign these name to new data frame

  ###Setting up levels of response variable for calculating distance
  ##checking to see if factor or numeric and allocate value for distance-for factors

  ##create new number of variables in dataframe for factor variable being assigned a distance
  v<-NULL
  for (i in 1:ns)
  {
    v[i]=paste("r_",i,sep="")
  }

  #check for factor or numerical and convert factor to numeric via defined distance inputted by level by user
  for (i in 1:ns)
  {

    if(class(as[[resp[i]]])=="factor")
    {    ll=levels(as[[resp[i]]])
    ln=length(ll)
    for(j in 1:ln)
    {as[[v[i]]][as[[resp[i]]]==ll[j]]<-levela[j]
    }

    }
    else
    {as[[v[i]]]=as[[resp[i]]]}
  }

  if(is.null(Cluster) || Cluster=="HC") {
    ##Hierarchical clustering

    a=stats::dist(x=as[v], method="euclidean")

    #hierarchical clustering model
    fit=stats::hclust(d=a)

    #cut size as defined by user
    rd=1
    while(rd>0)
    {
      cuta=(stats::cutree(fit, k=cut))
      ch=NULL
      for (i in 1:cut)
      {
        ch[i]=paste("x",i,sep="")
      }

      x_info=cbind(as[resp],cuta)
      cut.array=list()
      names1=NULL
      for (i in 1:cut)
      {
        cut.array[[i]]=subset(x_info[,1:ns], cuta==i)
        names1[i]=paste("cut_",i,sep="")  #names for objects in list
      }
      names(cut.array)=names1
      ##Find most common for each cut across all the response variables within cut
      nc=matrix(0, nrow=cut, ncol=ns)
      for (j in 1:cut)
      {for (i in 1:ns)
      {
        if(sort(table(unlist(cut.array[[names1[j]]][i])), decreasing=TRUE)[1]==sort(table(unlist(cut.array[[names1[j]]][i])), decreasing=TRUE)[2])
        {if(!is.null(seed))
        {
          set.seed(seed+1)
        }
          else{}
          nc[j,i]=names(sort(table(unlist(cut.array[[names1[j]]][i])), decreasing=TRUE)[sample.int(2,1)])

        }  #ties within each individual response variable when clustered
        else{
          nc[j,i]=names(sort(table(unlist(cut.array[[names1[j]]][i])), decreasing=TRUE)[1])}

      }
      }
      #defining overall variable for cut and defining in data frame
      n_resp=vector()
      for (i in 1:cut){
        n_resp[i]=names(sort(table(unlist(nc[i,])), decreasing=TRUE))[1]
      }


      tc=list()
      n_resp=vector()
      rd=vector()
      for (i in 1:cut){
        tc[[i]]=sort(table(unlist(nc[i,])), decreasing=TRUE)
        if(length(tc[[i]])==1 ){
          rd[i]=0
          n_resp[i]=names(sort(table(unlist(nc[i,])), decreasing=TRUE))[1]
        } else if(tc[[i]][1]==tc[[i]][2]) {
          rd[i]=1
          if(is.null(type) || type=="Standard"){
            n_resp[i]=names(sort(table(unlist(nc[i,])), decreasing=TRUE))[1]
          }
          else if(type=="Random")
          {
            if(!is.null(seed))
            {
              set.seed(seed)
            }
            else{}
            n_resp[i]=names(sort(table(unlist(nc[i,])), decreasing=TRUE))[sample(1:2,1)]
          }
          else if(type=="Tied")
          { rd[i]=1
          rownames(ties) <-levels(as.factor(as[[resp[1]]]))
          colnames(ties) <-levels(as.factor(as[[resp[1]]]))
          cc1=names(tc[[i]])[1]
          cc2=names(tc[[i]])[2]

          n_resp[i]=ties[cc1,cc2]
          }

        } else {
          rd[i]=0
          n_resp[i]=names(sort(table(unlist(nc[i,])), decreasing=TRUE))[1]  #no ties
        }
      }

      rd=sum(rd)

      ccn=cut
      cct[vp[ccn-(cv-1)]]=x_info[,ns+1]
      for (i in 1:cut){

        cct[vs[ccn-(cv-1)]][cct[vp[ccn-(cv-1)]]==i]<- n_resp[i]
      }


      if(cut>=maxcut){
        break
      }

      if(rd>0) {
        cut=cut+1
      } else {
      }

    }

    ##Selecting final model

    ##record classification rate
    class_tab <- data.frame(matrix(NA, ncol=ns, nrow=(maxcut-(cv-1)))) #create new dataframe to store classification rate
    names<-c(resp)    #assign names of represonse  to vector for use in a data frame
    colnames(class_tab)<-names     #assign these name to new data frame

    if(rd==0){  #Meaning all clear defined cuts were produced and no ties, return only this model
      as$cut=x_info[,ns+1]

      for (i in 1:cut){

        as$temp[as$cut==i]<- n_resp[i]
      }

      colnames(as)[which(names(as) == "temp")] <- comresp

      as_test=as

    } else{   #select best based on classification rate

      #merge dataframe
      ctdf=data.frame(cct,as)
      ct.rpart=list()
      forma=list()
      predsa=unlist(preds)
      if(is.null(cp))
      {
        cp=0.01 #default value
      } else{
        cp=cp
      }

      predtest=list()
      cfm=list()


      for (i in 1:(maxcut-(cv-1))){
        forma[[i]] <- stats::as.formula(paste(vs[i], paste(predsa, sep="", collapse ="+"), sep="~"))
        if(length(levels(ctdf[vs[i]]==1))){
          ct.rpart[[i-1]]= rpart::rpart(forma[[i]], data = ctdf, method = "class", cp=cp)
        }else{
          ct.rpart[[i]]= rpart::rpart(forma[[i]], data = ctdf, method = "class", cp=cp)
          as_test=data.frame(as)
        }
      }


      if(!is.null(weighted)){
        nw=length(weighted)
        crdf=data.frame(matrix(NA, ncol=nw, nrow=1))
        names<-c(weighted)    #assign names of response  to vector for use in a data frame
        colnames(crdf)<-names
        predtestb=list()
        for (i in 1:(maxcut-(cv-1))){
          for (j in 1:nw){
            as_test$resp1 <- as_test[weighted[j]][[1]]
            predtestb[[i]]=stats::predict(object=ct.rpart, newdata=as_test, type="class")
            as_test$predtestb<- predtestb[i][[1]]
            q=0
            for(a in 1:dime[1]){
              if(as_test$predtestb[[a]]==as_test$resp1[[a]]){
                q=q+1
              } else{

              }}
            crdf[i,j]=q/dime[1]
          } }
        crdf$average=rowSums(crdf)/nw
        wm=as.vector(crdf$average)
        for (m in 1:maxcut-(cv-1)){
          crdf$average[m][crdf$average[m]=="1"]<-NA
        }
        bc=which.max(wm)

        as$temp=cct[vs[bc]][[1]]
        as$cut=cct[vp[bc]][[1]]

        colnames(as)[which(names(as) == "temp")] <- comresp
      } else{
        crdf=data.frame(matrix(NA, ncol=ns, nrow=(cut-(cv-1))))
        names<-c(resp)    #assign names of represonse  to vector for use in a data frame
        colnames(crdf)<-names
        for (i in 1:(maxcut-(cv-1))){
          for (j in 1:ns){

            as_test[vs[i]] <- as_test[resp[j]][[1]]
            predtest[[i]]=stats::predict(object=ct.rpart[[i]], newdata=as_test, type="class")
            as_test$predtest<- predtest[i][[1]]
            q=0
            for(a in 1:dime[1]){
              if(as_test$predtest[[a]]==as_test[vs[i]][[1]][a]){
                q=q+1
              } else{

              }}
            crdf[i,j]=q/dime[1]
          } }
        crdf$average=rowSums(crdf)/ns
        for (m in 1:maxcut-(cv-1)){
          crdf$average[m][crdf$average[m]=="1"]<-NA
        }
        wm=as.vector(crdf$average)
        bc=which.max(wm)

        as$temp=cct[vs[bc]][[1]]
        as$cut=cct[vp[bc]][[1]]

        colnames(as)[which(names(as) == "temp")] <- comresp
      }

    }
  }

  else if (Cluster=="KNN") {
    #KNN with training data provided by user and test data being data provided for resp
    #error checking
    #Make sure training set has been included

    if(is.null(train)==TRUE)
    {
      stop("No training set for KNN has been provided, please add")
    }
    else {}
    ##Check to see if a seed was specified by the user
    if(!is.null(seed))
    {
      set.seed(seed)
    }
    else{}
    #Make sure all response variable are in training set
    for (i in 1:ns){

      if(as.factor(resp[i]) %in% names(train)==TRUE) {
      }
      else {

        stop("Response variable: ", resp[i], ", not in training data frame provided for kNN")
      }
    }
    #factors to add training size

    #training.labels=as.character(train$class)
    dime1=dim(train)
    train_dat<- data.frame(matrix(NA, ncol=(ns+1), nrow=dime1[1])) #create new dataframe from predictor and response variable
    names1<-c("class", resp)    #assign names of represonse and predictor variables to vector for use in a data frame
    colnames(train_dat)<-names1     #assign these name to new data frame
    train_dat$class=train$class
    tt=list()
    #normalisation of data set to be used by KNN
    norml <- function(x) {
      x <- as.numeric(as.character(x))
      y<-(x-min(x))/(max(x)-min(x))
      return(y)}
    #convert from factor into numeric and store in data frame for training
    for (i in 1:ns){
      tt[[i]]=train[[resp[i]]]
      tl=levels(tt[[i]])
      tt[[i]]=as.character(tt[[i]])
      for (j in 1:length(tl)){
        tt[[i]][tt[[i]]==tl[j]]<-levela[j]}
      tt[[i]]=norml(tt[[i]])
      train_dat[[resp[i]]]=tt[[i]]
    }
    test_dat= as[v]
    names2a<-c(resp)
    colnames(test_dat)<-names2a
    test_dat
    #put into normalization factor
    for (i in 1:ns){
      test_dat[resp[i]]=test_dat[resp[i]][[1]]
    }
    knn_cut <-class::knn(train=train_dat[resp],test_dat,cl=train_dat$class, k=cut)
    as[comresp]=knn_cut
    test_dat$knn_cut=knn_cut

    if(!is.null(weighted)){
      nw=length(weighted)
      crdf=data.frame(matrix(NA, ncol=nw, nrow=1))
      names<-c(weighted)    #assign names of response to vector for use in a data frame
      colnames(crdf)<-names

      for (j in 1:nw){
        test_dat$resp1 <- as[weighted[j]][[1]]
        q=0
        for(a in 1:dime[1]){
          if(test_dat$knn_cut[[a]]==test_dat$resp1[[a]]){
            q=q+1
          } else{
          }}
        crdf[1,j]=q/dime[1]
        rd=1
      }
      crdf$average=rowSums(crdf)/nw
    }else{
      crdf=data.frame(matrix(NA, ncol=ns, nrow=1))
      names<-c(resp)    #assign names of represonse  to vector for use in a data frame
      colnames(crdf)<-names
      for (j in 1:length(resp)){
        test_dat$resp1 <- as[resp[j]][[1]]
        q=0
        for(a in 1:dime[1]){
          if(test_dat$knn_cut[[a]]==test_dat$resp1[[a]]){
            q=q+1
          } else{
          }}
        crdf[1,j]=q/dime[1]
      }
      crdf$average=rowSums(crdf)/ns
      rd=1
    }
  } else {
    stop('Incorrect Cluster method entered, please enter "HC" for Hierachical Clustering or "KNN" for K Nearest Neighbors')
  }
  ## Produce CART model
  #check to see if complexity paramater included
  if(is.null(cp))
  {
    cp=0.01 #default value
  } else{
    cp=cp
  }
  form1=list()   #list of formula for simulation
  preds1=unlist(preds)
  form1 <- stats::as.formula(paste(as.name(comresp), paste(preds1, sep="", collapse ="+"), sep="~"))
  com.rpart= rpart::rpart(form1, data = as, method = "class", cp=cp)
  cct=Filter(function(x)!all(is.na(x)), cct)   #remove rows not in cuts if clear cut produce produced

  if(rd==0)      #if no ties, calculate classification rate
  {

    if(!is.null(weighted)){
      nw=length(weighted)
      crdf=data.frame(matrix(NA, ncol=nw, nrow=1))
      names<-c(weighted)    #assign names of represonse  to vector for use in a data frame
      colnames(crdf)<-names

      for (j in 1:nw){
        as_test$resp1 <- as_test[weighted[j]][[1]]
        predtest=stats::predict(object=com.rpart, newdata=as_test, type="class")
        as_test$predtest<- predtest
        q=0
        for(a in 1:dime[1]){
          if(as_test$predtest[[a]]==as_test$resp1[[a]]){
            q=q+1
          } else{
          }
        }
        crdf[1,j]=q/dime[1]
      }
      crdf$average=rowSums(crdf)/nw
      bc=c("All defined cluster cut at cut size ", cut)
    } else{
      crdf=data.frame(matrix(NA, ncol=ns, nrow=1))
      names<-c(resp)    #assign names of represonse  to vector for use in a data frame
      colnames(crdf)<-names
      predtesta=list()
      for (j in 1:ns){
        as_test$resp1 <- as_test[resp[j]][[1]]
        predtesta[[i]]=stats::predict(object=com.rpart, newdata=as_test, type="class")
        as_test$predtesta<- predtesta[i][[1]]
        q=0
        for(a in 1:dime[1]){
          if(as_test$predtesta[[a]]==as_test$resp1[[a]]){
            q=q+1
          } else{

          }}
        crdf[1,j]=q/dime[1]
      }
      crdf$average=rowSums(crdf)/ns
      bc=c("All defined cluster cut at cut size", cut)
    }
  }
  else {
  }
  visNetwork::visTree(com.rpart)
  if(is.null(Cluster) || Cluster=="HC") {
    p=list(data=as, rpart=com.rpart, plot=visNetwork::visTree(com.rpart), cuts=cct, classrate=crdf, run=bc)
  }
  else{p=list(data=as, rpart=com.rpart, plot=visNetwork::visTree(com.rpart), cuts=c("KNN used"), classrate=crdf, run=c("KNN used"))
  }
  return(p)
}
